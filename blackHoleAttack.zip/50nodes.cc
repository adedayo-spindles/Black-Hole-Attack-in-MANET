/* AODV Yönlendirme Protokolü ile Kara Delik(Black Hole) Saldırısı Simülasyonu 
 * 
 * Network topolojisi
 * 
 *    n0 --> n1 --> n2 --> n3 -->.. n49(50 düğümlü ise)
 * 
 * Her düğüm hemen bitişiğindeki aralıktadır.
 * Kaynak DÜğüm: n1
 * Hedef Düğüm: n49(50 düğümlü senaryoda)
 * Malicious Node(s): n9,n19,n29,n39,n49
 * 
 * Bu programın çıktısı:
 * 1. Yönlendirme tablosu bilgisi için blackhole.routes dosyası ve 
 * 2. NetAnim ile animasyonu görüntülemek için blackhole.xml dosyası oluşturur.
 * Akış hakkında ayrıntılı bilgi için lab-4.flowmon dosyasını netanim'de stats sekmesine geçip Flow-Monitor seçeneğinde seçerek bulabilirsiniz
 */
#include "ns3/aodv-module.h"
#include "ns3/netanim-module.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/applications-module.h"
#include "ns3/mobility-module.h"
#include "ns3/wifi-module.h"
#include "ns3/netanim-module.h"
#include "ns3/flow-monitor-module.h"
#include "ns3/mobility-module.h"
#include "myapp.h"

NS_LOG_COMPONENT_DEFINE ("Blackhole");

using namespace ns3;



void
ReceivePacket(Ptr<const Packet> p, const Address & addr)
{
	std::cout << Simulator::Now ().GetSeconds () << "\t" << p->GetSize() <<"\n";
}


int main (int argc, char *argv[])
{
  bool enableFlowMonitor = false;
  std::string phyMode ("DsssRate1Mbps");

  CommandLine cmd;
  cmd.AddValue ("EnableMonitor", "Enable Flow Monitor", enableFlowMonitor);
  cmd.AddValue ("phyMode", "Wifi Phy mode", phyMode);
  cmd.Parse (argc, argv);

// Düğümlerin oluşturulması
  NS_LOG_INFO ("Create nodes.");
// Tüm düğümler
  NodeContainer c; 
  NodeContainer not_malicious;
  NodeContainer malicious;
  c.Create(50);
  
  not_malicious.Add(c.Get(0));
  not_malicious.Add(c.Get(1));
  not_malicious.Add(c.Get(2));
  not_malicious.Add(c.Get(3));
  not_malicious.Add(c.Get(4));
  not_malicious.Add(c.Get(5));
  not_malicious.Add(c.Get(6));
  not_malicious.Add(c.Get(7));
  not_malicious.Add(c.Get(8));
  not_malicious.Add(c.Get(10));
  not_malicious.Add(c.Get(11));
  not_malicious.Add(c.Get(12));
  not_malicious.Add(c.Get(13));
  not_malicious.Add(c.Get(14));
  not_malicious.Add(c.Get(15));
  not_malicious.Add(c.Get(16));
  not_malicious.Add(c.Get(17));
  not_malicious.Add(c.Get(18));
  not_malicious.Add(c.Get(20));
  not_malicious.Add(c.Get(21));
  not_malicious.Add(c.Get(22));
  not_malicious.Add(c.Get(23));
  not_malicious.Add(c.Get(24));
  not_malicious.Add(c.Get(25));
  not_malicious.Add(c.Get(26));
  not_malicious.Add(c.Get(27));
  not_malicious.Add(c.Get(28));
  not_malicious.Add(c.Get(30));
  not_malicious.Add(c.Get(31));
  not_malicious.Add(c.Get(32));
  not_malicious.Add(c.Get(33));
  not_malicious.Add(c.Get(34));
  not_malicious.Add(c.Get(35));
  not_malicious.Add(c.Get(36));
  not_malicious.Add(c.Get(37));
  not_malicious.Add(c.Get(38));
  not_malicious.Add(c.Get(40));
  not_malicious.Add(c.Get(41));
  not_malicious.Add(c.Get(42));
  not_malicious.Add(c.Get(43));
  not_malicious.Add(c.Get(44));
  not_malicious.Add(c.Get(45));
  not_malicious.Add(c.Get(46));
  not_malicious.Add(c.Get(47));
  not_malicious.Add(c.Get(48));
  malicious.Add(c.Get(9));
  malicious.Add(c.Get(19));
  malicious.Add(c.Get(29));
  malicious.Add(c.Get(39));
  malicious.Add(c.Get(49));
  // WiFi kurulumu
  WifiHelper wifi;

  YansWifiPhyHelper wifiPhy =  YansWifiPhyHelper::Default ();
  wifiPhy.SetPcapDataLinkType (YansWifiPhyHelper::DLT_IEEE802_11);

  YansWifiChannelHelper wifiChannel ;
  wifiChannel.SetPropagationDelay ("ns3::ConstantSpeedPropagationDelayModel");
  wifiChannel.AddPropagationLoss ("ns3::TwoRayGroundPropagationLossModel",
	  	  	  	  	  	  	  	    "SystemLoss", DoubleValue(1),
		  	  	  	  	  	  	    "HeightAboveZ", DoubleValue(1.5));

  wifiPhy.Set ("TxPowerStart", DoubleValue(33));
  wifiPhy.Set ("TxPowerEnd", DoubleValue(33));
  wifiPhy.Set ("TxPowerLevels", UintegerValue(1));
  wifiPhy.Set ("TxGain", DoubleValue(0));
  wifiPhy.Set ("RxGain", DoubleValue(0));
  wifiPhy.Set ("EnergyDetectionThreshold", DoubleValue(-61.8));
  wifiPhy.Set ("CcaMode1Threshold", DoubleValue(-64.8));

  wifiPhy.SetChannel (wifiChannel.Create ());

  NqosWifiMacHelper wifiMac = NqosWifiMacHelper::Default ();
  wifiMac.SetType ("ns3::AdhocWifiMac");

  // 802.11b standardı
  wifi.SetStandard (WIFI_PHY_STANDARD_80211b);

  wifi.SetRemoteStationManager ("ns3::ConstantRateWifiManager",
                                "DataMode",StringValue(phyMode),
                                "ControlMode",StringValue(phyMode));


  NetDeviceContainer devices;
  devices = wifi.Install (wifiPhy, wifiMac, c);


  // AODV'yi etkinleştirir
  AodvHelper aodv;
  AodvHelper malicious_aodv; 
 

  InternetStackHelper internet;
  internet.SetRoutingHelper (aodv);
  internet.Install (not_malicious);
  
  malicious_aodv.Set("IsMalicious",BooleanValue(true)); // true yerine false koymak, düğümün saldırgan özelliğini devre dışı bırakır
  internet.SetRoutingHelper (malicious_aodv);
  internet.Install (malicious);

  // Adreslerin ayarlanması
  Ipv4AddressHelper ipv4;
  NS_LOG_INFO ("Assign IP Addresses.");
  ipv4.SetBase ("10.1.2.0", "255.255.255.0");
  Ipv4InterfaceContainer ifcont = ipv4.Assign (devices);


  NS_LOG_INFO ("Create Applications.");

  // N1'den N59'e UDP bağlantısı(50 düğümlü senaryo için)

  uint16_t sinkPort = 6;
  Address sinkAddress (InetSocketAddress (ifcont.GetAddress (49), sinkPort)); 
  PacketSinkHelper packetSinkHelper ("ns3::UdpSocketFactory", InetSocketAddress (Ipv4Address::GetAny (), sinkPort));
  ApplicationContainer sinkApps = packetSinkHelper.Install (c.Get (49)); 
  sinkApps.Start (Seconds (0.));
  sinkApps.Stop (Seconds (100.));

  Ptr<Socket> ns3UdpSocket = Socket::CreateSocket (c.Get (1), UdpSocketFactory::GetTypeId ()); 

  Ptr<MyApp> app = CreateObject<MyApp> ();
  app->Setup (ns3UdpSocket, sinkAddress, 1040, 5, DataRate ("250Kbps"));
  c.Get (1)->AddApplication (app);
  app->SetStartTime (Seconds (40.));
  app->SetStopTime (Seconds (100.));

// Düğümler için hareketlilik(mobility) ayarları

  MobilityHelper mobility;
  Ptr<ListPositionAllocator> positionAlloc = CreateObject <ListPositionAllocator>();
  positionAlloc ->Add(Vector(100, 0, 0)); // node0
  positionAlloc ->Add(Vector(200, 0, 0)); // node1 
  positionAlloc ->Add(Vector(450, 0, 0)); // node2
  positionAlloc ->Add(Vector(550, 0, 0)); // node3
  positionAlloc ->Add(Vector(800, 0, 0)); // node4
  positionAlloc ->Add(Vector(900, 0, 0)); // node5
  positionAlloc ->Add(Vector(1150, 0, 0)); // node6
  positionAlloc ->Add(Vector(1250, 0, 0)); // node7
  positionAlloc ->Add(Vector(1500, 0, 0)); // node8
  positionAlloc ->Add(Vector(1600, 0, 0)); // node9
  positionAlloc ->Add(Vector(100, 0, 0)); // node10
  positionAlloc ->Add(Vector(200, 0, 0)); // node11 
  positionAlloc ->Add(Vector(450, 0, 0)); // node12
  positionAlloc ->Add(Vector(550, 0, 0)); // node13
  positionAlloc ->Add(Vector(800, 0, 0)); // node14
  positionAlloc ->Add(Vector(900, 0, 0)); // node15
  positionAlloc ->Add(Vector(1150, 0, 0)); // node16
  positionAlloc ->Add(Vector(1250, 0, 0)); // node17
  positionAlloc ->Add(Vector(1500, 0, 0)); // node18
  positionAlloc ->Add(Vector(1600, 0, 0)); // node19
  positionAlloc ->Add(Vector(100, 0, 0)); // node20
  positionAlloc ->Add(Vector(200, 0, 0)); // node21 
  positionAlloc ->Add(Vector(450, 0, 0)); // node22
  positionAlloc ->Add(Vector(550, 0, 0)); // node23
  positionAlloc ->Add(Vector(800, 0, 0)); // node24
  positionAlloc ->Add(Vector(900, 0, 0)); // node25
  positionAlloc ->Add(Vector(1150, 0, 0)); // node26
  positionAlloc ->Add(Vector(1250, 0, 0)); // node27
  positionAlloc ->Add(Vector(1500, 0, 0)); // node28
  positionAlloc ->Add(Vector(1600, 0, 0)); // node29
  positionAlloc ->Add(Vector(100, 0, 0)); // node30
  positionAlloc ->Add(Vector(200, 0, 0)); // node31 
  positionAlloc ->Add(Vector(450, 0, 0)); // node32
  positionAlloc ->Add(Vector(550, 0, 0)); // node33
  positionAlloc ->Add(Vector(800, 0, 0)); // node34
  positionAlloc ->Add(Vector(900, 0, 0)); // node35
  positionAlloc ->Add(Vector(1150, 0, 0)); // node36
  positionAlloc ->Add(Vector(1250, 0, 0)); // node37
  positionAlloc ->Add(Vector(1500, 0, 0)); // node38
  positionAlloc ->Add(Vector(1600, 0, 0)); // node39
  positionAlloc ->Add(Vector(100, 0, 0)); // node40
  positionAlloc ->Add(Vector(200, 0, 0)); // node41 
  positionAlloc ->Add(Vector(450, 0, 0)); // node42
  positionAlloc ->Add(Vector(550, 0, 0)); // node43
  positionAlloc ->Add(Vector(800, 0, 0)); // node44
  positionAlloc ->Add(Vector(900, 0, 0)); // node45
  positionAlloc ->Add(Vector(1150, 0, 0)); // node46
  positionAlloc ->Add(Vector(1250, 0, 0)); // node47
  positionAlloc ->Add(Vector(1500, 0, 0)); // node48
  positionAlloc ->Add(Vector(1600, 0, 0)); // node49
  mobility.SetPositionAllocator(positionAlloc);
  mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");
  mobility.Install(c);


  AnimationInterface anim ("blackhole.xml"); 
  AnimationInterface::SetConstantPosition (c.Get (0), 0, 500);
  AnimationInterface::SetConstantPosition (c.Get (1), 200, 500);
  AnimationInterface::SetConstantPosition (c.Get (2), 400, 500);
  AnimationInterface::SetConstantPosition (c.Get (3), 600, 500); 
  AnimationInterface::SetConstantPosition (c.Get (4), 800, 500); 
  AnimationInterface::SetConstantPosition (c.Get (5), 1000, 500); 
  AnimationInterface::SetConstantPosition (c.Get (6), 1200, 500); 
  AnimationInterface::SetConstantPosition (c.Get (7), 1400, 500); 
  AnimationInterface::SetConstantPosition (c.Get (8), 1600, 500); 
  AnimationInterface::SetConstantPosition (c.Get (9), 1800, 500);
  AnimationInterface::SetConstantPosition (c.Get (10), 0, 700);
  AnimationInterface::SetConstantPosition (c.Get (11), 200, 700);
  AnimationInterface::SetConstantPosition (c.Get (12), 400, 700);
  AnimationInterface::SetConstantPosition (c.Get (13), 600, 700); 
  AnimationInterface::SetConstantPosition (c.Get (14), 800, 700); 
  AnimationInterface::SetConstantPosition (c.Get (15), 1000, 700); 
  AnimationInterface::SetConstantPosition (c.Get (16), 1200, 700); 
  AnimationInterface::SetConstantPosition (c.Get (17), 1400, 700); 
  AnimationInterface::SetConstantPosition (c.Get (18), 1600, 700); 
  AnimationInterface::SetConstantPosition (c.Get (19), 1800, 700);
  AnimationInterface::SetConstantPosition (c.Get (20), 0, 900);
  AnimationInterface::SetConstantPosition (c.Get (21), 200, 900);
  AnimationInterface::SetConstantPosition (c.Get (22), 400, 900);
  AnimationInterface::SetConstantPosition (c.Get (23), 600, 900); 
  AnimationInterface::SetConstantPosition (c.Get (24), 800, 900); 
  AnimationInterface::SetConstantPosition (c.Get (25), 1000, 900); 
  AnimationInterface::SetConstantPosition (c.Get (26), 1200, 900); 
  AnimationInterface::SetConstantPosition (c.Get (27), 1400, 900); 
  AnimationInterface::SetConstantPosition (c.Get (28), 1600, 900); 
  AnimationInterface::SetConstantPosition (c.Get (29), 1800, 900); 
  AnimationInterface::SetConstantPosition (c.Get (30), 0, 1100);
  AnimationInterface::SetConstantPosition (c.Get (31), 200, 1100);
  AnimationInterface::SetConstantPosition (c.Get (32), 400, 1100);
  AnimationInterface::SetConstantPosition (c.Get (33), 600, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (34), 800, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (35), 1000, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (36), 1200, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (37), 1400, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (38), 1600, 1100); 
  AnimationInterface::SetConstantPosition (c.Get (39), 1800, 1100);  
  AnimationInterface::SetConstantPosition (c.Get (40), 0, 1300);
  AnimationInterface::SetConstantPosition (c.Get (41), 200, 1300);
  AnimationInterface::SetConstantPosition (c.Get (42), 400, 1300);
  AnimationInterface::SetConstantPosition (c.Get (43), 600, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (44), 800, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (45), 1000, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (46), 1200, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (47), 1400, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (48), 1600, 1300); 
  AnimationInterface::SetConstantPosition (c.Get (49), 1800, 1300);  
  anim.EnablePacketMetadata(true);

      Ptr<OutputStreamWrapper> routingStream = Create<OutputStreamWrapper> ("blackhole.routes", std::ios::out);
      aodv.PrintRoutingTableAllAt (Seconds (45), routingStream);

  // Alınan Paketlerin Takibi İçin
  Config::ConnectWithoutContext("/NodeList/*/ApplicationList/*/$ns3::PacketSink/Rx", MakeCallback (&ReceivePacket));


//
// Flowmonitor kullanarak Çıktı Hesabı 
//
  FlowMonitorHelper flowmon;
  Ptr<FlowMonitor> monitor = flowmon.InstallAll();


  NS_LOG_INFO ("Run Simulation.");
  Simulator::Stop (Seconds(100.0));
  Simulator::Run ();

  monitor->CheckForLostPackets ();

  Ptr<Ipv4FlowClassifier> classifier = DynamicCast<Ipv4FlowClassifier> (flowmon.GetClassifier ());
  std::map<FlowId, FlowMonitor::FlowStats> stats = monitor->GetFlowStats ();
  for (std::map<FlowId, FlowMonitor::FlowStats>::const_iterator i = stats.begin (); i != stats.end (); ++i)
    {
	  Ipv4FlowClassifier::FiveTuple t = classifier->FindFlow (i->first);
      if ((t.sourceAddress=="10.1.2.2" && t.destinationAddress == "10.1.2.50"))
      {
          std::cout << "Flow " << i->first  << " (" << t.sourceAddress << " -> " << t.destinationAddress << ")\n";
          std::cout << "  Tx Bytes:   " << i->second.txBytes << "\n";
          std::cout << "  Rx Bytes:   " << i->second.rxBytes << "\n";
      	  std::cout << "  Throughput: " << i->second.rxBytes * 8.0 / (i->second.timeLastRxPacket.GetSeconds() - i->second.timeFirstTxPacket.GetSeconds())/1024/1024  << " Mbps\n";
      }
     }

  monitor->SerializeToXmlFile("lab-4.flowmon", true, true);


}
